
/**
 *
 * @author Luiz Merschmann
 */
public class Principal {

    public static void main(String[] args) {
        Simulacao sim = new Simulacao();
        sim.executarSimulacao(2240);
    }
}
