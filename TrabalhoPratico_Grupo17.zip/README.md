# Simulacao-Veiculos
Trabalho prático da disciplina de PPOO <br>
Forma de commit: https://gitmoji.dev/ **Ex:** :rocket: Adicionando arquivos inciais
